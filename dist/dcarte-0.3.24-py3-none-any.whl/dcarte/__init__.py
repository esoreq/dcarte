"""dcarte dataset fusion tools"""
from .__version__ import __author__, __copyright__, __title__, __version__
from .load import load
from .domains import domains

